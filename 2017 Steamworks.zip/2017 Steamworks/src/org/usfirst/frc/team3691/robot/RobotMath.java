package org.usfirst.frc.team3691.robot;

public class RobotMath {

	public static double[] Sort(double[] array)
	{
		double[] newArray = array;
		
		for(int i = 0; i < array.length; i++)
		{
			if(i+1 < array.length)
				if(array[i+1] < array[i])
				{
					double temp = array[i];
					array[i] = array[i+1];
					array[i+1] = temp;
					i = -1;
				}
		}
		
		return newArray;
	}
	
}
