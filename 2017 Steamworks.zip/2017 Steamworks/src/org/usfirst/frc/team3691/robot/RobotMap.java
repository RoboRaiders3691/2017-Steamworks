package org.usfirst.frc.team3691.robot;
/**
 * The RobotMap is a mapping from the ports sensors and actuators are wired into
 * to a variable name. This provides flexibility changing wiring, makes checking
 * the wiring easier and significantly reduces the number of magic numbers
 * floating around.
 */
public class RobotMap {
    
	public static int leftFrontMotor =  10;//2     10
	public static int leftBackMotor =   9;//1     9
	public static int rightFrontMotor = 8;//0     8
	public static int rightBackMotor =  7;//4     7
	
	public static int lift1 = 3;
	public static int lift2 = 5;
}
