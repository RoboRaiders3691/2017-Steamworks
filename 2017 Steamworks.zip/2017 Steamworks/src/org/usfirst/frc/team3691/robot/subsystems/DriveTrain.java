package org.usfirst.frc.team3691.robot.subsystems;

import org.usfirst.frc.team3691.robot.RobotMap;

import com.ctre.CANTalon;

import edu.wpi.first.wpilibj.ADXRS450_Gyro;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.command.Subsystem;

/**
 *
 */
public class DriveTrain extends Subsystem {
	
	//Talons
	public CANTalon talon1 = new CANTalon(RobotMap.leftFrontMotor);
	public CANTalon talon2 = new CANTalon(RobotMap.leftBackMotor);
	public CANTalon talon3 = new CANTalon(RobotMap.rightFrontMotor);
	public CANTalon talon4 = new CANTalon(RobotMap.rightBackMotor);
	
	public CANTalon talon5 = new CANTalon(RobotMap.lift1);
	public CANTalon talon6 = new CANTalon(RobotMap.lift2);
	
	//Sensors
	public ADXRS450_Gyro gyro = new ADXRS450_Gyro();
	
	//Robot Drive
	public RobotDrive myRobot;

	public DriveTrain(){
		myRobot = new RobotDrive(talon1, talon2, talon3, talon4);
		talon1.setInverted(true);
		talon2.setInverted(true);
		talon3.setInverted(true);
		talon4.setInverted(true);
	}
	
    public void initDefaultCommand() {
    }
}

