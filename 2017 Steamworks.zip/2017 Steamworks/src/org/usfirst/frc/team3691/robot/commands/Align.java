package org.usfirst.frc.team3691.robot.commands;

import org.usfirst.frc.team3691.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;

/**
 *
 */
public class Align extends Command {
	
	private double angle;
	private int direction;
	boolean finished = false;
	
    public Align(double angle, int direction) {
        
    	requires(Robot.driveTrain);
    	this.angle = angle;
    	this.direction = direction;
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    	double curAngle = Math.abs(Robot.driveTrain.gyro.getAngle()%360);
    	angle = Math.abs(angle);
    	
    	if(direction > 0)
    		Robot.driveTrain.myRobot.setLeftRightMotorOutputs(1.0, -1.0);
    	else
    		Robot.driveTrain.myRobot.setLeftRightMotorOutputs(-1.0, 1.0);
    	
    	if(curAngle >= angle-1 && curAngle <= angle+1)
    		finished = true;
    	
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return finished;
    }

    // Called once after isFinished returns true
    protected void end() {
    	Robot.driveTrain.myRobot.stopMotor();
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    }
}
