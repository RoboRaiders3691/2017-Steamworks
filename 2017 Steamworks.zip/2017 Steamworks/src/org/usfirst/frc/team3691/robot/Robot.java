
package org.usfirst.frc.team3691.robot;

import edu.wpi.cscore.CvSink;
import edu.wpi.cscore.CvSource;
import edu.wpi.cscore.UsbCamera;
import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.vision.VisionThread;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;
import org.usfirst.frc.team3691.robot.subsystems.DriveTrain;
import org.usfirst.frc.team3691.robot.vision.GripPipeline;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends IterativeRobot {
    
    //Sub Systems
    public static final DriveTrain driveTrain = new DriveTrain();

    public static OI oi;
    public static boolean moveForward = false, commandRunning = false;
    
    //Commands
    Command driveForward, locateTarget, alignRobot;
    
    //Camera
    public static final int WIDTH = 640;
    public static final int HEIGHT = 360;
    VisionThread visionThread;
    final Object imgLock = new Object();
    
    //Autonomous
    public final double SPEED = 3.99;//From Speed Calculation
    double centerX = 0.0;
    Rect rect1, rect2;
    boolean leftSide, rightSide;
    int mode = 1;
    boolean autoForward = true, autoSpin = false;
    boolean autoDistance = false;
    boolean baseLine = false, leftAuto = false, middleAuto = true, rightAuto = false;
    
    //Teleop
    public boolean gearLift = false;
    
    //Debug
    boolean debug = false, verbos = false;
    boolean rectangleDebug = false, hslDebug = false;
    CvSource hsl;
    
    //Table
    UsbCamera camera;
    GripPipeline pipeline;
    CvSink sink;
    CvSource source;
    Mat mat;
    
    public void robotInit() {
		oi = new OI();
		
		camera = CameraServer.getInstance().startAutomaticCapture();
		camera.setResolution(WIDTH, HEIGHT);
		
		if(debug)
			VisionDebugInit();
		
		AutonomousCamera();
		
		visionThread = new VisionThread(camera, new GripPipeline(), pipeline -> {
			if(!pipeline.filterContoursOutput().isEmpty()){//There is a filtered contour
				Rect[] rects = new Rect[pipeline.filterContoursOutput().size()];//Makes rectangle array
				for(int i = 0; i < pipeline.filterContoursOutput().size(); i++){//Fills rectangle array
					Rect r = Imgproc.boundingRect(pipeline.filterContoursOutput().get(i));
					rects[i] = r;
				}
				rects = bubbleSort(rects);//Bubble Sort Rectangles
				synchronized (imgLock){//Synchronized loop
					if(rects.length > 0){
						SmartDashboard.putNumber("Rectangles", rects.length);
						double width = 0;
						if(rects.length > 1){
							//SmartDashboard.putBoolean("One Rectangle", false);
							width = (rects[1].x-rects[0].x)+rects[1].width;//Width of the two rectangles combined
							rect2 = rects[1];//Sets width of rectangle
							gearLift = true;//Auto gear lift for teleop
							if(verbos)
								SmartDashboard.putNumber("Rect 2 X", rects[1].x);
							
							if(autoSpin){
								autoSpin = false;
								driveTrain.myRobot.stopMotor();
								SmartDashboard.putBoolean("Auto Spin", false);
							}
							
							if(autoForward && (mode != 2 || mode != 3))//Moving forward but found two rectangles
								autoForward = false;
							
						}else{//Only 1 rectangle
							//SmartDashboard.putBoolean("One Rectangle", true);
							if(autoSpin){
								autoSpin = false;
								driveTrain.myRobot.stopMotor();
								SmartDashboard.putBoolean("Auto Spin", false);
							}
							
							width = rects[0].width;//Width is rectangle
							gearLift = false;//Auto gear lift
						}
						centerX = rects[0].x + width/2;//Finds center of our width
						rect1 = rects[0];
						if(verbos)
							SmartDashboard.putNumber("Rect 1 X", rects[0].x);
					}
					else//0 rectangles
						centerX = 0;
				}
				if(debug)
					VisionDebugUpdate(rects);
			}
		});
		visionThread.start();
    }
	 
    Rect[] bubbleSort(Rect[] rects){//Sorts rectangles from 
    	for(int i = 0; i < rects.length-1; i++)
    		if(rects[i].area() > rects[i+1].area()){//Swap
    			Rect temp = rects[i+1];
    			rects[i+1] = rects[i];
    			rects[i] = temp;
    			i = -1;
    		}
    	
    	if(rects.length > 1)
	    	if(rects[1].x < rects[0].x){//Swap so #1 is on the left
	    		Rect temp = rects[0];
	    		rects[0] = rects[1];
	    		rects[1] = temp;
	    	}
    	return rects;
    }
    
    void VisionDebugInit(){
    	sink = CameraServer.getInstance().getVideo(camera);
    	if(!rectangleDebug && hslDebug)
    		 hsl = CameraServer.getInstance().putVideo("Rectangle", WIDTH/2, HEIGHT/2);
    	else if(rectangleDebug)
    		DrawRectInit();
    }
    
    void VisionDebugUpdate(Rect[] rects){
    	//Changeable Vision Values
    	GripPipeline.hueMin = SmartDashboard.getNumber("HueMin", GripPipeline.hueMin);
    	GripPipeline.hueMax = SmartDashboard.getNumber("HueMax", GripPipeline.hueMax);
    	GripPipeline.saturationMin = SmartDashboard.getNumber("SaturationMin", GripPipeline.saturationMin);
    	GripPipeline.saturationMax = SmartDashboard.getNumber("SaturationMax", GripPipeline.saturationMax);
    	GripPipeline.valMin = SmartDashboard.getNumber("ValueMin", GripPipeline.valMin);
    	GripPipeline.valMax = SmartDashboard.getNumber("ValueMax", GripPipeline.valMax);
    	
    	//Camera Updates
    	if(!rectangleDebug && hslDebug)
    		hsl.putFrame(pipeline.hsvThresholdOutput());
    	else if(rectangleDebug)
    		DrawRectangles(rects, pipeline);
    	
    	//Verbos
    	if(verbos){
    		System.out.println("Rect Size: " + rects.length);
    		System.out.println("Rect 0: " + rects[0].x + " " + rects[0].y + " " + rects[0].width + " " + rects[0].height);
    	}
    }
    
    /**Disabled Mode**/
    public void disabledInit(){
    	SmartDashboard.putBoolean("Debug", debug);
    	AutoDashboard();
    }
    
    void AutoDashboard(){
    	SmartDashboard.putBoolean("Baseline", baseLine);
    	SmartDashboard.putBoolean("Left Gear", leftAuto);
    	SmartDashboard.putBoolean("Middle Gear", middleAuto);
    	SmartDashboard.putBoolean("Right Gear", rightAuto);
    }
	
	public void disabledPeriodic() {
		boolean temp = debug;
		debug = SmartDashboard.getBoolean("Debug", false);
		if(!temp && debug)
			VisionDebugInit();
		
		boolean tBase = baseLine, tLeft = leftAuto, tMiddle = middleAuto, tRight = rightAuto;
		
		baseLine = SmartDashboard.getBoolean("Baseline", false);
		leftAuto = SmartDashboard.getBoolean("Left Gear", false);
    	middleAuto = SmartDashboard.getBoolean("Middle Gear", false);
    	rightAuto = SmartDashboard.getBoolean("Right Gear", false);
    	
    	if(baseLine && !tBase){
    		leftAuto = false;
    		rightAuto = false;
    		middleAuto = false;
    		mode = 4;
    		AutoDashboard();
    	}else if(leftAuto && !tLeft){
    		baseLine = false;
    		rightAuto = false;
    		middleAuto = false;
    		mode = 2;
    		AutoDashboard();
    	}else if(rightAuto && !tRight){
    		leftAuto = false;
    		baseLine = false;
    		middleAuto = false;
    		mode = 3;
    		AutoDashboard();
    	}else if(middleAuto && !tMiddle){
    		leftAuto = false;
    		rightAuto = false;
    		baseLine = false;
    		mode = 1;
    		AutoDashboard();
    	}
	}

	/**Autonomous Mode**/
    public void autonomousInit() {
    	lastTurn = -1;
    	curSpeed = 0.5;
    	leftSide = false;
    	rightSide = false;
    	autoForward = true;
    	canMove = true;
    	wait = false;
    	done = false;
    	timeout = false;
    	driveTrain.gyro.reset();
    	AutonomousCamera();
    }

    double lastTurn = -1, curSpeed = 0.5;
    boolean canMove = true;
    public void autonomousPeriodic() {
    	DashboardOutputs();
    	double centerX = 0.0;
    	synchronized (imgLock){
    		centerX = this.centerX;
    	}
    	double turn = 0;
    	if(centerX != 0 && !autoForward && !autoSpin){
	    	turn = centerX-(WIDTH/2);
	    	turn *= -0.6;
	    	
	    	if(lastTurn != -1 && Math.abs(turn-lastTurn) > 50)
	    		turn = 0;
	    	
	    	if(rect1 != null && !leftSide){
		    	if(rect1.x < 20 && rect1.y < 10)
		    		leftSide = true;
	    	}else if(rect1 != null && rect2 == null && leftSide){//Left Side is clear out of vision
	    		if(((rect1.x+rect1.width) > WIDTH-5) || rect1.x < 5)
		    		rightSide = true;
	    	}
	    	
	    	if(rect2 != null)
		    	if((rect2.x+rect2.width) > WIDTH-20 && rect2.y < 10)
		    		rightSide = true;
	    	
	    	//Special Movement
	    	if(rect1 != null && rect2 == null && leftSide){
	    		canMove = false;
	    		if(!(rect1.height+5 >= HEIGHT))
	    			driveTrain.myRobot.arcadeDrive(curSpeed, 0.0);
	    		else
	    			driveTrain.myRobot.tankDrive(0.0, curSpeed);
	    	}
	    	
	    	SmartDashboard.putBoolean("Left Side", leftSide);
	    	SmartDashboard.putBoolean("Right Side", rightSide);
	    	
	    	if(leftSide && rightSide){
	    		curSpeed = 0;
	    		autoForward = false;
	    		autoSpin = false;
	    		canMove = true;
	    		SmartDashboard.putBoolean("End", true);
	    	}else
	    		SmartDashboard.putBoolean("End", false);
	    	
	    	lastTurn = turn;
    	}
    	
    	//Mode 1
    	if(mode == 1 && autoForward){
    		curSpeed = 0.5;
    		turn = -driveTrain.gyro.getAngle();
    	}
    	
    	//Mode 2 and 3
    	if((mode == 2 || mode == 3) && autoForward && !moveForward && !autoDistance){
    		//DriveDistance(12, 0.5);
    		autoDistance = true;
    		moveForward = true;
    		SmartDashboard.putBoolean("Auto Forward", true);
    	}else if((mode == 2 || mode == 3) && autoForward && !moveForward && autoDistance){
    		autoForward = false;
    		autoSpin = true;
    		SmartDashboard.putBoolean("Auto Forward", false);
    		SmartDashboard.putBoolean("Auto Spin", true);
    	}
    	
    	if((mode == 2 || mode == 3) && !wait)
    		AutoWait(2.5);
    	
    	/*if(mode == 2 && moveForward && done){
    		if(rect2 != null){
    			if(rect2.x+rect2.width >= WIDTH-20)
    				moveForward = false;
    		}else if(rect1 != null){
    			if(rect1.x+rect1.width >= WIDTH-20)
    				moveForward = false;
    		}
    	}
    	
    	if(mode == 3 && moveForward && done){
    		if(rect1 != null){
    			if(rect1.x <= 20)
    				moveForward = false;
    		}
    	}*/
    	
    	//Mode 4
    	if(mode == 4 && !wait){
    		AutoWait(7);
    	}else if(mode == 4 && done){
    		curSpeed = 0;
    	}else if(mode == 4){
    		turn = -driveTrain.gyro.getAngle();
    	}
    	
    	if((mode == 2 || mode == 3) && autoForward && moveForward && !autoDistance)
    		turn = -driveTrain.gyro.getAngle();
    	
    	if((mode == 2 || mode == 3) && !autoSpin && !autoForward){
    		curSpeed = 0.5;
    		turn = -driveTrain.gyro.getAngle();
    	}
    	
    	if(autoSpin)
    		if(mode == 2)
    			driveTrain.myRobot.tankDrive(0.65, -0.65);
    		else if(mode == 3)
    			driveTrain.myRobot.tankDrive(-0.65, 0.65);
    	
    	//All Modes
    	if(curSpeed != 0 && !autoSpin && canMove && !timeout)
			driveTrain.myRobot.arcadeDrive(curSpeed, turn*0.005);
    	else if(!autoSpin && canMove)
    		driveTrain.myRobot.arcadeDrive(0.0, 0.0);
    	
    	//Verbos
    	if(verbos){
    		System.out.println("Rect 0: " + rect1.x + " " + rect1.y + " " + rect1.width + " " + rect1.height);
    		System.out.println("Rect 0: " + rect2.x + " " + rect2.y + " " + rect1.width + " " + rect1.height);
    	}
    }
    
    boolean wait = false;
    boolean done = false;
    void AutoWait(double waitTime){
    	wait = true;
    	curSpeed = 0.8;
    	Timer timer = new Timer();
    	timer.schedule(new TimerTask(){
			@Override
			public void run() {
				done = true;
				moveForward = false;
				curSpeed = 0.5;
				AutoSpinStop();
			}
    	}, (long)(waitTime*1000));
    }
    
    boolean timeout = false;
    void AutoTimeout(){
    	Timer timer = new Timer();
    	timer.schedule(new TimerTask(){
			@Override
			public void run() {
				timeout = true;
			}
    	}, (long)(7*1000));
    }
    
    void AutoSpinStop(){
    	Timer timer = new Timer();
    	timer.schedule(new TimerTask(){
			@Override
			public void run() {
				autoSpin = false;
				AutoTimeout();
			}
    	}, (long)(1000));
    }
    
    double time = 0;
    void DriveDistance(double distance, double robotSpeed){
    	time = distance/(SPEED*robotSpeed);
    	moveForward = true;
    	
    	Timer timer = new Timer();
    	timer.schedule(new TimerTask(){
			@Override
			public void run() {
				Robot.moveForward = false;
				Robot.driveTrain.myRobot.stopMotor();
			}
    	}, (long)(time*1000));
    }
    
    /**Teleop Mode**/
    public void teleopInit() {
    	if(locateTarget != null)
    		locateTarget.cancel();
    	
    	TeleopCamera();
    	driveTrain.gyro.reset();
    }
    
    double deadZone = 0.01;
    public void teleopPeriodic() {
        DashboardOutputs();
        
        if(oi.rightStick.getRawButton(1)){//Rope climber activated by right trigger
        	driveTrain.talon5.set(oi.rightStick.getZ());
        	driveTrain.talon6.set(oi.rightStick.getZ());
        }else{
        	driveTrain.talon5.set(0);
        	driveTrain.talon6.set(0);    
        }
        
        if(commandRunning && (oi.leftStick.getY() >= deadZone || oi.leftStick.getY() <= -deadZone) 
        		&& (oi.rightStick.getY() != 0 || oi.rightStick.getY() <= -deadZone)){
        	commandRunning = false;
        	TeleopCamera();
        }
        
        if(oi.leftStick.getRawButton(2)){
        	commandRunning = false;
        	TeleopCamera();
        }
        
        if(gearLift && oi.leftStick.getRawButton(1)){
        	commandRunning = true;
        	curSpeed = 0.5;
        	AutonomousCamera();
        }
        
        if(!commandRunning)//No Command is running drive normally
        	driveTrain.myRobot.arcadeDrive(oi.leftStick);
        else
        	DriveToGear();
    }
    
    void DriveToGear(){
    	double centerX = 0;
    	synchronized(imgLock){
    		centerX = this.centerX;
    	}
    	double turn = centerX-(WIDTH/2);
    	turn *= -0.6;
    	
    	if(lastTurn != -1 && Math.abs(turn-lastTurn) > 50)
    		turn = 0;
    	
    	if(rect1 != null && !leftSide){
	    	if(rect1.x < 5)
	    		leftSide = true;
    	}else if(rect1 != null && rect2 == null && leftSide){//Left Side is clear out of vision
    		if(((rect1.x+rect1.width) > WIDTH-5) || rect1.x < 5)
	    		rightSide = true;
    	}
    	
    	if(rect2 != null)
	    	if((rect2.x+rect2.width) > WIDTH-5)
	    		rightSide = true;
    	
    	if(leftSide && rightSide){
    		curSpeed = 0;
    		commandRunning = false;
    		TeleopCamera();
    	}
    	
    	
    	driveTrain.myRobot.arcadeDrive(curSpeed, turn*0.005);
    }
    
    public static double getDistance(double pixelHeight){
    	return 150.0 / (2 * pixelHeight * 0.54347826095294447386888551785504);
    }
    
    void DrawRectInit(){
    	hsl = CameraServer.getInstance().putVideo("Rectangle", WIDTH/2, HEIGHT/2);
    	mat = new Mat();
    }
    
    void DrawRectangles(Rect[] rects, GripPipeline pipeline){
    	sink.grabFrame(mat);
    	Imgproc.rectangle(mat, new Point(rects[0].x, rects[0].y), new Point(rects[0].x+rects[0].width, rects[0].y+rects[0].height), 
				new Scalar(0, 255, 0), 3);
    	hsl.putFrame(mat);
    }
    
    void DashboardOutputs(){
    	SmartDashboard.putNumber("Angle", driveTrain.gyro.getAngle());//Angle
    	SmartDashboard.putBoolean("Gear Lift", gearLift);//Gear Lift
    }
    
    void AutonomousCamera(){
    	try {
			Runtime.getRuntime().exec("v4l2-ctl -c brightness=200");
			Runtime.getRuntime().exec("v4l2-ctl -c white_balance_temperature_auto=0");
			Runtime.getRuntime().exec("v4l2-ctl -c white_balance_temperature=2800");
			Runtime.getRuntime().exec("v4l2-ctl -c exposure_auto=1");
			Runtime.getRuntime().exec("v4l2-ctl -c exposure_absolute=0");
			Runtime.getRuntime().exec("v4l2-ctl -c contrast=5");
			Runtime.getRuntime().exec("v4l2-ctl -c saturation=82");
			Runtime.getRuntime().exec("v4l2-ctl -c sharpness=25");
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
    void TeleopCamera(){
    	try {
			Runtime.getRuntime().exec("v4l2-ctl -c brightness=143");
			Runtime.getRuntime().exec("v4l2-ctl -c white_balance_temperature_auto=0");
			Runtime.getRuntime().exec("v4l2-ctl -c white_balance_temperature=2800");
			Runtime.getRuntime().exec("v4l2-ctl -c exposure_auto=1");
			Runtime.getRuntime().exec("v4l2-ctl -c exposure_absolute=6");
			Runtime.getRuntime().exec("v4l2-ctl -c contrast=5");
			Runtime.getRuntime().exec("v4l2-ctl -c saturation=82");
			Runtime.getRuntime().exec("v4l2-ctl -c sharpness=25");
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
    /**Test Mode**/
    public void testPeriodic() {
        LiveWindow.run();
    }
}
